package com.assignment.finalproject;

import java.util.ArrayList;
import java.util.Date;

public class Event {

    public static ArrayList<Event> eventArrayList = new ArrayList<>();
    public static  String NOTE_EDIT_EXTRA = "eventEdit";
    private int id;
    private String title;
    private String dueDate;
    private Date deleted;

    public Event(int id, String title, String dueDate, Date deleted) {
        this.id = id;
        this.title = title;
        this.dueDate = dueDate;
        this.deleted = deleted;
    }

    public Event(int id, String title, String dueDate) {
        this.id = id;
        this.title = title;
        this.dueDate = dueDate;
        deleted = null;
    }

    public static Event getEventForID(int passedEventID) {
        for (Event event : eventArrayList){
            if(event.getId() == passedEventID)
                return event;
        }
        return null;
    }
    public static ArrayList<Event> nonDeletedEvents(){
        ArrayList<Event> nonDeleted = new ArrayList<>();
        for (Event event : eventArrayList){
            if(event.getDeleted() == null){
                nonDeleted.add(event);
            }
        }
        return nonDeleted;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public Date getDeleted() {
        return deleted;
    }

    public void setDeleted(Date deleted) {
        this.deleted = deleted;
    }
}
