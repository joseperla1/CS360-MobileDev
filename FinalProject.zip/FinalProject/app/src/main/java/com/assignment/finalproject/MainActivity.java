package com.assignment.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.AdapterListUpdateCallback;

public class MainActivity extends AppCompatActivity {
    private ListView eventListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initWidget();
        loadFromDBToMemory();
        setEventAdapter();
        setOnClickListener();



    }




    private void initWidget() {
        eventListView = findViewById(R.id.eventListView);
    }
    private void loadFromDBToMemory() {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.populateEventListArray();
    }

    private void setEventAdapter() {
        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(), Event.nonDeletedEvents());
        eventListView.setAdapter(eventAdapter);
    }
    private void setOnClickListener() {
        eventListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                Event selectedEvent = (Event) eventListView.getItemAtPosition(position);
                Intent editEventIntent = new Intent(getApplicationContext(), EventDetailActivity.class);
                editEventIntent.putExtra(Event.NOTE_EDIT_EXTRA, selectedEvent.getId());
                startActivity(editEventIntent);

            }
        });
    }

    public void newEvent(View view) {
        Intent newEventIntent = new Intent(this, com.assignment.finalproject.EventDetailActivity.class);
        startActivity(newEventIntent);
    }
    @Override
    protected void onResume() {
        super.onResume();
        // Refresh the ListView when the MainActivity resumes
        setEventAdapter();
//        ((EventAdapter) eventListView.getAdapter()).notifyDataSetChanged();
    }
}