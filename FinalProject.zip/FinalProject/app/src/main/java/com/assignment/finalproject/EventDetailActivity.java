package com.assignment.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Date;

public class EventDetailActivity extends AppCompatActivity {
    private EditText titleEditText, dueDateEditText;
    private Event selectedEvent;
    private Button deletedButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);
        initWidgets();
        checkForEditEvent();

    }


    private void initWidgets() {
        titleEditText=findViewById(R.id.titleEditText);
        dueDateEditText=findViewById(R.id.dueDateEditText);
        deletedButton=findViewById(R.id.deleteEventButton);
    }
    private void checkForEditEvent() {
         Intent previousIntent = getIntent();
         int passedEventID = previousIntent.getIntExtra(Event.NOTE_EDIT_EXTRA, - 1);
         selectedEvent = Event.getEventForID(passedEventID);

         if (selectedEvent != null){
             titleEditText.setText(selectedEvent.getTitle());
             dueDateEditText.setText(selectedEvent.getDueDate());
         }
         else {
             deletedButton.setVisibility(View.INVISIBLE);
         }

    }


    public void saveEvent(View view) {
        SQLiteManager sqLiteManager =SQLiteManager.instanceOfDatabase(this);

        String title = String.valueOf(titleEditText.getText());
        String dueDate = String.valueOf(dueDateEditText.getText());
        if (selectedEvent == null){
            int id = Event.eventArrayList.size();
            Event newEvent = new Event(id, title, dueDate);
            Event.eventArrayList.add(newEvent);
            sqLiteManager.addEventToDatabase(newEvent);
        }
        else {
            selectedEvent.setTitle(title);
            selectedEvent.setDueDate(dueDate);
            sqLiteManager.updateEventInDB(selectedEvent);
        }

        finish();
    }


    public void deleteEvent(View view) {
        selectedEvent.setDeleted(new Date());
        SQLiteManager sqLiteManager =SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.updateEventInDB(selectedEvent);
        finish();
    }
}